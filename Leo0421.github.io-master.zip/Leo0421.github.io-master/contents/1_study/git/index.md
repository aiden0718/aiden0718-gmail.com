# Git

source: `{{ page.path }}`

> __기본 명령어__
>> [ref 1](https://theorydb.github.io/envops/2019/05/22/envops-blog-how-to-use-md/)
>> + __git pull__ : git서버에서 최신 코드 받아와 merge 하기
>> + __git add file_path__ : 수정한 코드 선택하기 ( git add * )
>> + __git commit -m “commit_description”__ : 선택한 코드 설명 적기 ( git commit -m “내용”)
>> + __git push romote_name branch_name__ : add하고 commit한 코드 git server에 보내기 (git push origin master)
