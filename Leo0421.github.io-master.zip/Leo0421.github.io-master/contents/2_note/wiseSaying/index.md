# wiseSaying

source: `{{ page.path }}`

- 단점을 고치는게 힘들면 장점을 더 살려라( 유투버 수학 포기 ).
- 나다운 것을 찾아라.
