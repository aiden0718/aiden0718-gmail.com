# 2. note

source: `{{ page.path }}`
